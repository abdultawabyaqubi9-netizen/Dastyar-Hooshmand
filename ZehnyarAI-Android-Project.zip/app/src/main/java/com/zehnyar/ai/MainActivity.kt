package com.zehnyar.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: Button
    private val navy = Color.rgb(15, 23, 42)
    private val blue = Color.rgb(37, 99, 235)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 250, 252))
            setPadding(16, 12, 16, 12)
        }
        val header = TextView(this).apply {
            text = "ذهنیار AI\nدستیار هوشمند شما"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(12, 18, 12, 18)
            setBackgroundColor(navy)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this)
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 12, 4, 12)
        }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "پیامت را بنویس..."
            textSize = 16f
            singleLine = false
            minLines = 1
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        send = Button(this).apply {
            text = "ارسال"
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { sendMessage() }
        }
        row.addView(send)
        root.addView(row)
        setContentView(root)

        addBubble("سلام! من ذهنیار AI هستم. پیام خود را بنویس. برای پاسخ هوشمند، کلید Gemini API را در تنظیمات مخزن GitHub وارد کن.", false)
    }

    private fun addBubble(text: String, user: Boolean) {
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(if (user) Color.WHITE else Color.rgb(15, 23, 42))
            setPadding(14, 10, 14, 10)
            setBackgroundColor(if (user) blue else Color.rgb(226, 232, 240))
        }
        val params = LinearLayout.LayoutParams(
            if (user) (resources.displayMetrics.widthPixels * 0.78).toInt() else (resources.displayMetrics.widthPixels * 0.88).toInt(),
            -2
        )
        params.gravity = if (user) Gravity.END else Gravity.START
        params.setMargins(4, 6, 4, 6)
        messages.addView(bubble, params)
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        addBubble(prompt, true)
        if (BuildConfig.GEMINI_API_KEY.isBlank()) {
            addBubble("اتصال هوش مصنوعی هنوز فعال نشده است. در GitHub به Settings → Secrets and variables → Actions برو و یک Secret با نام GEMINI_API_KEY بساز، سپس برنامه را دوباره بساز.", false)
            return
        }
        send.isEnabled = false
        addBubble("در حال فکر کردن…", false)
        thread {
            val answer = try { askGemini(prompt) } catch (e: Exception) {
                "ارتباط برقرار نشد: ${e.message ?: "خطای نامشخص"}. اینترنت را بررسی کن."
            }
            runOnUiThread {
                send.isEnabled = true
                addBubble(answer, false)
            }
        }
    }

    private fun askGemini(prompt: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${BuildConfig.GEMINI_API_KEY}")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
        val json = JSONObject(response)
        return json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }
}
