# ذهنیار AI — پروژه اندروید

اپلیکیشن بومی Android با Kotlin برای گفت‌وگو با Gemini API.

## ساخت APK از طریق GitHub Actions
1. محتویات این پروژه را در ریشه مخزن `Dastyar-Hooshmand` قرار دهید.
2. در مخزن GitHub از مسیر **Settings → Secrets and variables → Actions → New repository secret** یک Secret با نام `GEMINI_API_KEY` ایجاد کنید و کلید Gemini API را در مقدار آن وارد کنید. کلید را داخل کد یا README قرار ندهید.
3. به تب **Actions** بروید و گردش کار **Build signed debug APK** را اجرا کنید، یا با commit جدید اجرای خودکار را فعال کنید.
4. در اجرای موفق، بخش **Artifacts** فایل `ZehnyarAI-debug-apk` را برای دانلود دارد.

این گردش کار APK دیباگِ امضاشده با کلید دیباگ Android تولید می‌کند. برای انتشار عمومی در Google Play، باید یک کلید امضای انتشار اختصاصی و امن پیکربندی شود؛ کلید دیباگ برای انتشار نهایی مناسب نیست.

## نیازمندی
- Android Studio/Gradle و JDK 17 برای ساخت محلی
- کلید API معتبر Gemini برای پاسخ‌های واقعی هوش مصنوعی
